#extern version.glsl

in vec2		pass_uv;
in vec3		pass_normal;
in float	pass_ao;

out	vec4 vertexColor;

uniform sampler2D skinTexture;

void main(void) {
	vec4 diffuse = texture(skinTexture, pass_uv);
	vertexColor = vec4(diffuse.xyz * pass_ao, diffuse.w);
}
