#extern version.glsl

in vec2 pass_uv;
in vec3 pass_normal;
flat in vec4 pass_color;

out	vec4 vertexColor;

uniform sampler2D diffuseMap;

const vec3 lightDirection = normalize(vec3(1.0, 1.0, 1.0));

void main(void) {
	vertexColor = pass_color;
}
