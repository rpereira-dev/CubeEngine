#extern version.glsl

in vec2 pass_uv;
in vec3 pass_normal;

out	vec4 vertexColor;

uniform sampler2D skinTexture;

const vec3 lightDirection = normalize(vec3(-1.0, -1.0, -1.0));
const vec2 lightBias = vec2(0.7, 0.6);

void main(void) {
	vec4 diffuse = texture(skinTexture, pass_uv);		
	float light = max(dot(-lightDirection, pass_normal), 0.0) * lightBias.x + lightBias.y;	
	vertexColor = vec4(diffuse.xyz * light, diffuse.w);
}
