#extern version.glsl

in vec4 pass_uv;
in float pass_brightness;
in vec3 transf_normal;
in vec3 to_sun_vector;
in float pass_reflection;

out vec4 vertexColor;

uniform vec3 sun_color;
uniform float sun_intensity;
uniform float ambient_light;

uniform sampler2D tx_atlas;
uniform sampler2D tx_reflection;
uniform sampler2D tx_refraction;
uniform sampler2D tx_dudvmap;
uniform sampler2D tx_normalsmap;

const float uuvx = 1 / float(16);
const float uuvy = 1 / float(16);

void main(void)
{
	//if it is water
	if (pass_reflection > 0) {
		discard ;
	}
	
		//texture on the atlas
	float uvx = pass_uv.x * uuvx + mod(pass_uv.z, 1.0) * uuvx;
	float uvy = pass_uv.y * uuvy + mod(pass_uv.w, 1.0) * uuvy;
	vec4 tx_color = texture(tx_atlas, vec2(uvx, uvy));
	
	//light rendering
	float n = dot(transf_normal, to_sun_vector);
	float intensity = max(n * sun_intensity, ambient_light);
	vec3 diffuse = intensity * sun_color * pass_brightness;
	vec4 color = tx_color * vec4(diffuse, 1.0);
	vertexColor = color;
}