#extern version.glsl

in vec2 pass_uv;
in vec3 pass_normal;

out	vec4 vertexColor;

uniform sampler2D diffuseMap;

const vec3 lightDirection = normalize(vec3(1.0, 1.0, 1.0));

void main(void) {
	vec3 diffuseColour = texture(diffuseMap, pass_uv).rgb;		
	float diffuseLight = max(dot(-lightDirection, pass_normal), 0.4);
	vertexColor = vec4(diffuseColour * diffuseLight, 1.0);
}
