#extern version.glsl

in vec2 uv;

out vec4 vertexColor;

uniform sampler2D tx_fbo;

vec4 blurh(sampler2D tx, vec2 uv)
{
	vec4 color = vec4(0.0);
		
	color += texture2D(tx, uv + vec2(-0.028, +0.000)) * 0.0044299121055113265;
    color += texture2D(tx, uv + vec2(-0.024, +0.000)) * 0.00895781211794;
    color += texture2D(tx, uv + vec2(-0.020, +0.000)) * 0.0215963866053;
    color += texture2D(tx, uv + vec2(-0.016, +0.000)) * 0.0443683338718;
    color += texture2D(tx, uv + vec2(-0.012, +0.000)) * 0.0776744219933;
    color += texture2D(tx, uv + vec2(-0.008, +0.000)) * 0.115876621105;
    color += texture2D(tx, uv + vec2(-0.004, +0.000)) * 0.147308056121;
    color += texture2D(tx, uv + vec2(+0.004, +0.000)) * 0.159576912161;
    color += texture2D(tx, uv + vec2(+0.008, +0.000)) * 0.159576912161;
    color += texture2D(tx, uv + vec2(+0.012, +0.000)) * 0.115876621105;
    color += texture2D(tx, uv + vec2(+0.016, +0.000)) * 0.0776744219933;
    color += texture2D(tx, uv + vec2(+0.020, +0.000)) * 0.0215963866053;
    color += texture2D(tx, uv + vec2(+0.024, +0.000)) * 0.00895781211794;
    color += texture2D(tx, uv + vec2(+0.028, +0.000)) * 0.0044299121055113265;
    
    return color;
}

void main()
{	
	vertexColor = blurh(tx_fbo, uv);
}