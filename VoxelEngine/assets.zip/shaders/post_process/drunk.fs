#version 330 core

in vec2 uv;

out vec4 vertexColor;

uniform sampler2D tx_fbo;
uniform float time;

void main(void)
{
	vec2 tx_coords = uv.xy;
	tx_coords.x += sin(uv.y * 8.0 + time) / 64.0f;
	tx_coords.x = clamp(tx_coords.x, 0.0, 1.0);	
	vertexColor = texture2D(tx_fbo, tx_coords);
}
