#extern version.glsl

out	vec4 vertexColor;

void main(void) {
	vertexColor = vec4(1.0);
}
