#version 330 core

in vec2 uv;

out vec4 vertexColor;

uniform sampler2D texture_sampler;

void main(void)
{
	vertexColor = texture(texture_sampler, uv);	
}
