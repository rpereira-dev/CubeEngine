#version 330 core

in vec2 uv;

out vec4 vertexColor;

uniform sampler2D texture_sampler;
uniform float alpha;

void main(void) {
	vec4 txColor = texture(texture_sampler, uv);	
	vertexColor = vec4(txColor.r, txColor.g, txColor.b, txColor.a * alpha);
}
