#extern version.glsl

in vec4 pass_uv;
flat in int pass_color;
in float visibility;
in vec3 transf_normal;
in vec3 to_sun_vector;
in vec3 to_camera_vector;
in float pass_brightness;

out vec4 vertexColor;

uniform vec3 fog_color;

uniform vec3 sun_color;
uniform float sun_intensity;
uniform float ambient_light;

# define MESH_TYPE_OPAQUE (0)
# define MESH_TYPE_TRANSPARENT (1)
uniform int mesh_type;

uniform sampler2D tx_atlas;

const float uuvx = 1 / float(16);
const float uuvy = 1 / float(16);

void main(void) {
	//if nearly not visible, set color as fog
	if (visibility < 0.01) {
		vertexColor = vec4(fog_color, 1.0);
		return ;
	}

	//texture on the atlas
	float uvx = pass_uv.x * uuvx + mod(pass_uv.z, 1.0) * uuvx;
	float uvy = pass_uv.y * uuvy + mod(pass_uv.w, 1.0) * uuvy;
	vec4 tx_color = texture(tx_atlas, vec2(uvx, uvy));
	//if pixel has transparency, discard it (plants...)
	if (tx_color.w < 0.99 && mesh_type == MESH_TYPE_OPAQUE) {
		discard ;
	}
	
	//multiply by coloration
	tx_color.r *= ((pass_color >> 16) & 0xFF) / 255.0f;
	tx_color.g *= ((pass_color >>  8) & 0xFF) / 255.0f;
	tx_color.b *= ((pass_color >>  0) & 0xFF) / 255.0f;
	tx_color.a *= ((pass_color >> 24) & 0xFF) / 255.0f;

	float f = pass_brightness;
	vec4 color = tx_color * vec4(f, f, f, 1.0);
		
	//apply fog
	vec4 fogged_color = mix(vec4(fog_color, 1.0), color, visibility);

	vertexColor = fogged_color;
}