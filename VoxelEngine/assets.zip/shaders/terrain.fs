#extern version.glsl

in float square_camera_dist;
in vec4 clipspace_coordinates;
in vec4 pass_uv;
in float pass_color;
in float visibility;
in vec3 transf_normal;
in vec3 to_sun_vector;
in vec2 dudv_uv;
in vec3 to_camera_vector;
in vec4 shadow_coords;
in float pass_brightness;

out vec4 vertexColor;

uniform vec3 fog_color;

uniform vec3 sun_color;
uniform float sun_intensity;
uniform float ambient_light;

uniform sampler2D tx_atlas;
uniform sampler2D tx_shadowmap;

uniform float move_factor;

const float distortion_strength = 0.004;
const float reflectivity = 0.5;

const float uuvx = 1 / float(16);
const float uuvy = 1 / float(16);

uniform float shadow_map_size;
uniform int shadow_pcf_count;

const float depth_bias = 0.007;

float calculateShadowFactor() {

	int pcf = shadow_pcf_count;
	float total_texels = (pcf * 2.0 + 1.0) * (pcf * 2.0 + 1.0);
	float texelsize = 1.0 / shadow_map_size;
	int total_shadow = 0;
	
	for (int x = -pcf; x <= pcf; x++) {
		for (int y = -pcf; y <= pcf; y++) {
			float light_hit_distance = texture(tx_shadowmap, shadow_coords.xy + vec2(x, y) * texelsize).r;
			//we hitted an object
			if (light_hit_distance + depth_bias < shadow_coords.z) {
				++total_shadow;
			}
		}
	}

	if (total_shadow == 0) {
		return (1.0);
	}

	float shadow_factor = shadow_coords.w * 0.4 * total_shadow / total_texels;
	return (1 - shadow_factor);
}

void main(void)
{
	//if nearly not visible, set color as fog
	if (visibility < 0.1) {
		vertexColor = vec4(fog_color, 1.0);
		return ;
	}

	//texture on the atlas
	float uvx = pass_uv.x * uuvx + mod(pass_uv.z, 1.0) * uuvx;
	float uvy = pass_uv.y * uuvy + mod(pass_uv.w, 1.0) * uuvy;
	vec4 tx_color = texture(tx_atlas, vec2(uvx, uvy));
	
	//multiply by coloration
	//tx_color.r *= ((pass_color >> 16) & 0xFF) / 255.0f;
	//tx_color.g *= ((pass_color >>  8) & 0xFF) / 255.0f;
	//tx_color.b *= ((pass_color >>  0) & 0xFF) / 255.0f;
	//tx_color.a *= ((pass_color >> 24) & 0xFF) / 255.0f;

	//render light
	float n = dot(transf_normal, to_sun_vector);
	float intensity = max(n * sun_intensity, ambient_light);
	vec3 diffuse = intensity * sun_color * pass_brightness;
	//vec4 color = tx_color * vec4(diffuse * calculateShadowFactor(), 1.0);
	vec4 color = tx_color * vec4(diffuse, 1.0);
		
	//apply fog
	vec4 fogged_color = mix(vec4(fog_color, 1.0), color, visibility);

	//apply blur effect

	vertexColor = fogged_color;
}