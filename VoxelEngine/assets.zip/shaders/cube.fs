#extern version.glsl

in vec4 pass_color;
in float pass_face;
in float pass_health;

out vec4 vertexColor;

void main(void)
{
	float r = pass_color.x * pass_face;
	float g = pass_color.y * pass_face;
	float b = pass_color.z * pass_face;
	float a = pass_color.w;
		
	if (pass_health <= 0.2)
	{
		float ratio = pass_health / 0.2;
		a = a * ratio;
	}
	
	vertexColor = vec4(r, g, b, a);
}
