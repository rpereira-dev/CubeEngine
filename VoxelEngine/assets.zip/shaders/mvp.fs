#extern version.glsl

in float visibility;

out	vec4 vertexColor;

uniform vec4 color;
uniform vec3 fog_color;

void main(void) {	
	//apply fog
	vec4 fogged_color = mix(vec4(fog_color, 1.0), color, visibility);
	vertexColor = fogged_color;
}
