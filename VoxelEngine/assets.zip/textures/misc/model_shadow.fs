#extern version.glsl

out vec4 vertexColor;

uniform sampler2D tx_atlas;

void main(void) {
	vertexColor = vec4(1.0);
}
